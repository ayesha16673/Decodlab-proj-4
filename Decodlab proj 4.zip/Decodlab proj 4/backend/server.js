/**
 * Yummy Restaurant - Backend API (Project 3: Database Integration)
 * Ab Express + MongoDB (Mongoose) use hota hai.
 * Frontend ke API calls (/api/bookings, /api/contact, /api/menu) bilkul waisay hi
 * kaam karte hain jaise Project 2 mein — sirf data ab permanent store hota hai.
 */

require("dotenv").config();
const express = require("express");
const cors = require("cors");
const mongoSanitize = require("express-mongo-sanitize");
const connectDB = require("./config/db");

const menuRoutes = require("./routes/menuRoutes");
const bookingRoutes = require("./routes/bookingRoutes");
const contactRoutes = require("./routes/contactRoutes");

const PORT = process.env.PORT || 5000;

const app = express();

// ---------- Middleware ----------
app.use(cors());          // frontend ko API call karne dega
app.use(express.json());  // JSON request body parse karega
app.use(mongoSanitize());  // "$" jaise operators user input se strip karega (NoSQL injection se bachao)

// simple request logger (jaisa Project 2 mein tha)
app.use((req, res, next) => {
  console.log(`${new Date().toISOString()} - ${req.method} ${req.url}`);
  next();
});

// ---------- Routes ----------
app.get("/", (req, res) => {
  res.json({
    success: true,
    message: "Welcome to the Yummy Restaurant API 🍽️ (Project 3 - MongoDB)",
    endpoints: {
      menu: "GET /api/menu, GET /api/menu/:category",
      bookings: "GET /api/bookings, POST /api/bookings, GET /api/bookings/:id, PUT /api/bookings/:id, DELETE /api/bookings/:id",
      contact: "GET /api/contact, POST /api/contact"
    }
  });
});

app.use("/api/menu", menuRoutes);
app.use("/api/bookings", bookingRoutes);
app.use("/api/contact", contactRoutes);

// 404 handler
app.use((req, res) => {
  res.status(404).json({ success: false, message: `Route ${req.originalUrl} not found.` });
});

// Global error handler
app.use((err, req, res, next) => {
  console.error(err);
  res.status(500).json({ success: false, message: "Something went wrong on the server." });
});

// ---------- Start server (DB se connect hone ke baad) ----------
connectDB().then(() => {
  app.listen(PORT, () => {
    console.log(`✅ Yummy Backend API running at http://localhost:${PORT}`);
  });
});
