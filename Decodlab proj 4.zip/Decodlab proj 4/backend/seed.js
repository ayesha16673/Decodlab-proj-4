// seed.js
// Ye script sirf EK BAAR chalani hai — purana menu.js ka data
// MongoDB collection mein daal deti hai.
//
// Run karne ka tarika:  node seed.js

require("dotenv").config();
const connectDB = require("./config/db");
const MenuItem = require("./models/MenuItem");
const oldMenu = require("./data/menu");

async function seed() {
  await connectDB();

  // Pehle purana data clear karo (taake dobara run karne se duplicate na banein)
  await MenuItem.deleteMany({});
  console.log("Old menu items cleared.");

  const allItems = [];
  for (const category of Object.keys(oldMenu)) {
    oldMenu[category].forEach((item) => {
      allItems.push({
        name: item.name,
        description: item.description,
        price: item.price,
        image: item.image,
        category: category
      });
    });
  }

  await MenuItem.insertMany(allItems);
  console.log(`✅ ${allItems.length} menu items seeded successfully.`);

  process.exit(0);
}

seed().catch((err) => {
  console.error("Seeding failed:", err.message);
  process.exit(1);
});
