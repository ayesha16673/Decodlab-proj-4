// This data mirrors the menu items already in index.html (starters, breakfast, lunch, dinner)
// In a real DB-based project this would come from MongoDB/MySQL, but for Project 2
// (pure API logic, no DB yet) we keep it in-memory.

let menu = {
  starters: [
    { id: 1, name: "MAGNUM TASTE", description: "Crispy on the outside, tender on the inside — the perfect way to start your meal.", price: 5.95, image: "menu-item-1.png" },
    { id: 2, name: "MAGNUM TASTE", description: "A light and flavorful bite made with fresh herbs and seasonal vegetables.", price: 5.95, image: "menu-item-2.png" },
    { id: 3, name: "MAGNUM TASTE", description: "Our signature starter, packed with rich flavor and a satisfying crunch.", price: 5.95, image: "menu-item-3.png" },
    { id: 4, name: "MAGNUM TASTE", description: "A savory appetizer prepared fresh, perfect for sharing with friends.", price: 5.95, image: "menu-item-4.png" },
    { id: 5, name: "MAGNUM TASTE", description: "Bold spices and fresh ingredients come together in this favorite starter.", price: 5.95, image: "menu-item-5.png" },
    { id: 6, name: "MAGNUM TASTE", description: "A classic dish reinvented with a modern twist and vibrant flavors.", price: 5.95, image: "menu-item-6.png" }
  ],
  breakfast: [
    { id: 7, name: "MAGNUM TASTE", description: "Start your morning right with our hearty, freshly prepared breakfast plate.", price: 5.95, image: "menu-item-1.png" },
    { id: 8, name: "MAGNUM TASTE", description: "A light and wholesome option made with fresh eggs and seasonal produce.", price: 5.95, image: "menu-item-2.png" },
    { id: 9, name: "MAGNUM TASTE", description: "Warm, comforting, and full of flavor — a breakfast favorite among our guests.", price: 5.95, image: "menu-item-3.png" },
    { id: 10, name: "MAGNUM TASTE", description: "A classic breakfast dish made with love and the freshest ingredients.", price: 5.95, image: "menu-item-4.png" },
    { id: 11, name: "MAGNUM TASTE", description: "Perfectly balanced flavors to fuel your day, made fresh every morning.", price: 5.95, image: "menu-item-5.png" },
    { id: 12, name: "MAGNUM TASTE", description: "A hearty option packed with protein and rich, satisfying flavor.", price: 5.95, image: "menu-item-6.png" }
  ],
  lunch: [
    { id: 13, name: "MAGNUM TASTE", description: "A satisfying midday meal made with fresh, seasonal ingredients.", price: 5.95, image: "menu-item-1.png" },
    { id: 14, name: "MAGNUM TASTE", description: "Light yet filling, this dish is a favorite among our lunch guests.", price: 5.95, image: "menu-item-2.png" },
    { id: 15, name: "MAGNUM TASTE", description: "A flavorful lunch option that's quick to serve but rich in taste.", price: 5.95, image: "menu-item-3.png" },
    { id: 16, name: "MAGNUM TASTE", description: "Freshly prepared with quality ingredients, ideal for a mid-day break.", price: 5.95, image: "menu-item-4.png" },
    { id: 17, name: "MAGNUM TASTE", description: "A well-balanced dish combining texture, spice, and freshness.", price: 5.95, image: "menu-item-5.png" },
    { id: 18, name: "MAGNUM TASTE", description: "Rich flavors and generous portions make this a lunch favorite.", price: 5.95, image: "menu-item-6.png" }
  ],
  dinner: [
    { id: 19, name: "MAGNUM TASTE", description: "End your day with a rich, satisfying dinner made just for you.", price: 5.95, image: "menu-item-1.png" },
    { id: 20, name: "MAGNUM TASTE", description: "A hearty evening dish full of bold flavors and fresh ingredients.", price: 5.95, image: "menu-item-2.png" },
    { id: 21, name: "MAGNUM TASTE", description: "A perfect way to wind down the day with a warm, comforting meal.", price: 5.95, image: "menu-item-3.png" },
    { id: 22, name: "MAGNUM TASTE", description: "Our chef's special dinner dish, prepared fresh with premium ingredients.", price: 5.95, image: "menu-item-4.png" },
    { id: 23, name: "MAGNUM TASTE", description: "A rich and flavorful dish perfect for sharing at the dinner table.", price: 5.95, image: "menu-item-5.png" },
    { id: 24, name: "MAGNUM TASTE", description: "A comforting classic, made fresh every evening for our guests.", price: 5.95, image: "menu-item-6.png" }
  ]
};

module.exports = menu;
