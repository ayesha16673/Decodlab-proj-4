// config/db.js
// Yeh file MongoDB se connection banati hai using Mongoose.
// Mongoose Node.js aur MongoDB ke beech "bridge" ka kaam karta hai (ORM).

const mongoose = require("mongoose");

async function connectDB() {
  try {
    const uri = process.env.MONGO_URI;
    if (!uri) {
      throw new Error("MONGO_URI not found in .env file");
    }

    await mongoose.connect(uri);
    console.log("✅ MongoDB connected successfully");
  } catch (err) {
    console.error("❌ MongoDB connection failed:", err.message);
    process.exit(1); // agar DB connect na ho, server start hi nahi hoga
  }
}

module.exports = connectDB;
