// models/Booking.js
// Table reservation ka schema. Yeh purane "bookings" array ki jagah leta hai.

const mongoose = require("mongoose");

const bookingSchema = new mongoose.Schema(
  {
    name: {
      type: String,
      required: [true, "Name is required."],
      trim: true
    },
    email: {
      type: String,
      required: [true, "Email is required."],
      trim: true,
      match: [/^[^\s@]+@[^\s@]+\.[^\s@]+$/, "Email format is invalid."]
    },
    phone: {
      type: String,
      required: [true, "Phone is required."],
      trim: true
    },
    date: {
      type: String, // simple string rakha hai jaise pehle tha (e.g. "2026-07-15")
      required: [true, "Date is required."]
    },
    time: {
      type: String,
      required: [true, "Time is required."]
    },
    people: {
      type: Number,
      required: [true, "Number of people is required."],
      min: [1, "Number of people must be a positive number."]
    },
    message: {
      type: String,
      trim: true,
      default: ""
    },
    status: {
      type: String,
      enum: ["pending", "confirmed", "cancelled"],
      default: "pending"
    }
  },
  { timestamps: true } // createdAt aur updatedAt khud add ho jayenge
);

module.exports = mongoose.model("Booking", bookingSchema);
