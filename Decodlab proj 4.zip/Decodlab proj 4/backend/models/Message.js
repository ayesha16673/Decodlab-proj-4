// models/Message.js
// Contact form ke messages ka schema. Purane "messages" array ki jagah.

const mongoose = require("mongoose");

const messageSchema = new mongoose.Schema(
  {
    name: {
      type: String,
      required: [true, "Name is required."],
      trim: true
    },
    email: {
      type: String,
      required: [true, "Email is required."],
      trim: true,
      match: [/^[^\s@]+@[^\s@]+\.[^\s@]+$/, "Email format is invalid."]
    },
    subject: {
      type: String,
      required: [true, "Subject is required."],
      trim: true
    },
    message: {
      type: String,
      required: [true, "Message is required."],
      trim: true
    }
  },
  { timestamps: true }
);

module.exports = mongoose.model("Message", messageSchema);
