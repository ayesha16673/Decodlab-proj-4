// models/MenuItem.js
// Menu items ab hardcoded object ki jagah MongoDB collection se aayenge.

const mongoose = require("mongoose");

const menuItemSchema = new mongoose.Schema(
  {
    name: {
      type: String,
      required: true,
      trim: true
    },
    description: {
      type: String,
      trim: true,
      default: ""
    },
    price: {
      type: Number,
      required: true,
      min: [0, "Price cannot be negative."]
    },
    image: {
      type: String,
      default: ""
    },
    category: {
      type: String,
      required: true,
      enum: ["starters", "breakfast", "lunch", "dinner"], // sirf yeh 4 categories allowed
      lowercase: true
    }
  },
  { timestamps: true }
);

module.exports = mongoose.model("MenuItem", menuItemSchema);
