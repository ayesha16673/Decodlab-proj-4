// routes/menuRoutes.js

const express = require("express");
const router = express.Router();
const MenuItem = require("../models/MenuItem");

// GET /api/menu  -> sab categories grouped
router.get("/", async (req, res) => {
  const items = await MenuItem.find();

  // frontend ke old format se match karne ke liye category-wise group kar dete hain
  const grouped = { starters: [], breakfast: [], lunch: [], dinner: [] };
  items.forEach((item) => {
    if (grouped[item.category]) grouped[item.category].push(item);
  });

  res.json({ success: true, data: grouped });
});

// GET /api/menu/:category
router.get("/:category", async (req, res) => {
  const category = req.params.category.toLowerCase();
  const validCategories = ["starters", "breakfast", "lunch", "dinner"];

  if (!validCategories.includes(category)) {
    return res.status(404).json({
      success: false,
      message: `Menu category '${category}' not found. Valid categories: starters, breakfast, lunch, dinner.`
    });
  }

  const items = await MenuItem.find({ category });
  res.json({ success: true, category, data: items });
});

module.exports = router;
