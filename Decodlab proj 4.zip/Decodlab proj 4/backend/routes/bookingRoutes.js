// routes/bookingRoutes.js
// CRUD = Create, Read, Update, Delete — sab yahan hain.

const express = require("express");
const router = express.Router();
const Booking = require("../models/Booking");

// CREATE  ->  POST /api/bookings
router.post("/", async (req, res) => {
  try {
    const booking = await Booking.create(req.body);
    res.status(201).json({
      success: true,
      message: "Table booked successfully!",
      data: booking
    });
  } catch (err) {
    // Mongoose validation errors ko clean list mein convert karo
    if (err.name === "ValidationError") {
      const errors = Object.values(err.errors).map((e) => e.message);
      return res.status(400).json({ success: false, message: "Validation failed.", errors });
    }
    res.status(500).json({ success: false, message: "Something went wrong." });
  }
});

// READ ALL  ->  GET /api/bookings
router.get("/", async (req, res) => {
  const bookings = await Booking.find().sort({ createdAt: -1 });
  res.json({ success: true, count: bookings.length, data: bookings });
});

// READ ONE  ->  GET /api/bookings/:id
router.get("/:id", async (req, res) => {
  try {
    const booking = await Booking.findById(req.params.id);
    if (!booking) {
      return res.status(404).json({ success: false, message: `Booking with id ${req.params.id} not found.` });
    }
    res.json({ success: true, data: booking });
  } catch (err) {
    res.status(400).json({ success: false, message: "Invalid booking id." });
  }
});

// UPDATE  ->  PUT /api/bookings/:id
// (Project 2 mein yeh nahi tha — Project 3 ke liye add kiya gaya taake full CRUD ho)
router.put("/:id", async (req, res) => {
  try {
    const updated = await Booking.findByIdAndUpdate(req.params.id, req.body, {
      new: true, // updated document wapas do, purana nahi
      runValidators: true // schema validation update pe bhi chale
    });
    if (!updated) {
      return res.status(404).json({ success: false, message: `Booking with id ${req.params.id} not found.` });
    }
    res.json({ success: true, message: "Booking updated successfully.", data: updated });
  } catch (err) {
    if (err.name === "ValidationError") {
      const errors = Object.values(err.errors).map((e) => e.message);
      return res.status(400).json({ success: false, message: "Validation failed.", errors });
    }
    res.status(400).json({ success: false, message: "Invalid booking id." });
  }
});

// DELETE  ->  DELETE /api/bookings/:id
router.delete("/:id", async (req, res) => {
  try {
    const deleted = await Booking.findByIdAndDelete(req.params.id);
    if (!deleted) {
      return res.status(404).json({ success: false, message: `Booking with id ${req.params.id} not found.` });
    }
    res.json({ success: true, message: `Booking ${req.params.id} cancelled successfully.` });
  } catch (err) {
    res.status(400).json({ success: false, message: "Invalid booking id." });
  }
});

module.exports = router;
