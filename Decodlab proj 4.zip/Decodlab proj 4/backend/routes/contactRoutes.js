// routes/contactRoutes.js

const express = require("express");
const router = express.Router();
const Message = require("../models/Message");

// CREATE  ->  POST /api/contact
router.post("/", async (req, res) => {
  try {
    const message = await Message.create(req.body);
    res.status(201).json({
      success: true,
      message: "Your message has been sent successfully!",
      data: message
    });
  } catch (err) {
    if (err.name === "ValidationError") {
      const errors = Object.values(err.errors).map((e) => e.message);
      return res.status(400).json({ success: false, message: "Validation failed.", errors });
    }
    res.status(500).json({ success: false, message: "Something went wrong." });
  }
});

// READ ALL  ->  GET /api/contact
router.get("/", async (req, res) => {
  const messages = await Message.find().sort({ createdAt: -1 });
  res.json({ success: true, count: messages.length, data: messages });
});

module.exports = router;
