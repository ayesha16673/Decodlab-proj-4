const secondnav = document.querySelector(".secondnav")
const sidebar = document.querySelector(".sidebar")

function showsecondnav() {
    if (sidebar.style.display === 'none') {
        sidebar.style.display = 'block'

    } else {
        sidebar.style.display = 'none'
    }

}
function hidesecondnav() {
    if (sidebar.style.display === 'none') {
        sidebar.style.display = 'block'
    } else {
        sidebar.style.display = 'none'
    }

}
 

 
function toggleMenu() {
    document.querySelector('.nav-items').classList.toggle('active');
}

function showMenu(category, element) {
    document.querySelectorAll('.menu-items').forEach(menu => {
        menu.classList.remove('active');
    });
    document.getElementById(category).classList.add('active');

    document.querySelectorAll('.nav-links li a').forEach(nav => {
        nav.classList.remove('active');
    });
    element.classList.add('active');
}


const slider = document.getElementById("slider");
let index = 0;

function autoSlide() {
    index++;
    if (index >= slider.children.length) {
        index = 0;  }
    slider.style.transform = `translateX(-${index * 100}%)`;
    slider.style.transition = "transform 0.5s ease-in-out";
}

setInterval(autoSlide, 3000);  

// Change this if your backend runs on a different port/host
const API_BASE_URL = "http://localhost:5000";

// ============================================================
// Project 4: Frontend & Backend Integration — Dynamic Menu
// Fetches menu data from the backend (GET /api/menu) and
// renders it into the DOM instead of using hardcoded HTML.
// ============================================================

async function loadMenu() {
    const loadingEl = document.getElementById('menu-loading');
    const errorEl = document.getElementById('menu-error');
    const errorTextEl = document.getElementById('menu-error-text');
    const categories = ['starters', 'breakfast', 'lunch', 'dinner'];

    loadingEl.style.display = 'block';
    errorEl.style.display = 'none';

    try {
        const response = await fetch(`${API_BASE_URL}/api/menu`);

        // Check the HTTP status before trusting the body
        if (!response.ok) {
            throw new Error(`HTTP Error! Status: ${response.status}`);
        }

        const result = await response.json();

        if (!result.success) {
            throw new Error(result.message || 'Failed to load menu.');
        }

        categories.forEach((category) => {
            renderMenuCategory(category, result.data[category] || []);
        });
    } catch (err) {
        console.error('Menu load failed:', err);
        errorTextEl.textContent = 'Could not load the menu. Make sure the backend is running, then retry.';
        errorEl.style.display = 'block';
    } finally {
        // Always runs, success or failure — no stuck spinners
        loadingEl.style.display = 'none';
    }
}

function renderMenuCategory(category, items) {
    const container = document.querySelector(`#${category} .menu-items-container`);
    if (!container) return;

    container.innerHTML = ''; // clear previous render (safe: no data injected here yet)

    if (items.length === 0) {
        const empty = document.createElement('p');
        empty.textContent = 'No items available in this category yet.';
        container.appendChild(empty);
        return;
    }

    // Group items into rows of 3 to match the original design (.start1 rows)
    for (let i = 0; i < items.length; i += 3) {
        const row = document.createElement('div');
        row.className = 'start1';

        items.slice(i, i + 3).forEach((item, idx) => {
            const col = document.createElement('div');
            col.className = 'col-md-4';

            const img = document.createElement('img');
            img.src = `./assets/${item.image}`;
            img.alt = item.name || '';
            if (i === 0 && idx === 0) img.width = 200;

            const h3 = document.createElement('h3');
            h3.textContent = item.name;   // textContent, not innerHTML -> XSS-safe

            const p = document.createElement('p');
            p.textContent = item.description;

            const span = document.createElement('span');
            span.textContent = `$${Number(item.price).toFixed(2)}`;

            col.appendChild(img);
            col.appendChild(h3);
            col.appendChild(p);
            col.appendChild(span);
            row.appendChild(col);
        });

        container.appendChild(row);
    }
}

// Kick off the menu fetch as soon as the page loads
document.addEventListener('DOMContentLoaded', loadMenu);

async function formdata(event) {
    event.preventDefault(); // stop the page from reloading

    let a = document.getElementById('name').value;
    let b = document.getElementById('email').value;
    let c = document.getElementById('phone').value;
    let d = document.getElementById('date').value;
    let e = document.getElementById('time').value;
    let f = document.getElementById('people').value;
    let g = document.getElementById('message').value;

    if (a == "" || b == "" || c == "" || d == "" || e == "" || f == "") {
        alert('all fields are mandatory');
        return;
    }

    try {
        const response = await fetch(`${API_BASE_URL}/api/bookings`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                name: a,
                email: b,
                phone: c,
                date: d,
                time: e,
                people: f,
                message: g
            })
        });

        const result = await response.json();

        if (result.success) {
            alert('Table booked successfully! We will see you soon 🍽️');
            event.target.reset(); // clear the form
        } else {
            alert('Please fix the following:\n' + result.errors.join('\n'));
        }
    } catch (err) {
        console.error(err);
        alert('Could not connect to the server. Make sure the backend is running (node server.js).');
    }
}

async function sendMessage(event) {
    event.preventDefault();

    let name = document.getElementById('contact-name').value;
    let email = document.getElementById('contact-email').value;
    let subject = document.getElementById('contact-subject').value;
    let message = document.getElementById('contact-message').value;

    if (name == "" || email == "" || subject == "" || message == "") {
        alert('all fields are mandatory');
        return;
    }

    try {
        const response = await fetch(`${API_BASE_URL}/api/contact`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ name, email, subject, message })
        });

        const result = await response.json();

        if (result.success) {
            alert('Your message has been sent successfully!');
            event.target.reset();
        } else {
            alert('Please fix the following:\n' + result.errors.join('\n'));
        }
    } catch (err) {
        console.error(err);
        alert('Could not connect to the server. Make sure the backend is running (node server.js).');
    }
}



function startCounter() {
    const counters = document.querySelectorAll('.number');
    const speed = 50; // Lower = Faster

    counters.forEach(counter => {
        const target = counter.getAttribute('data-target');
        let count = 0;

        const updateCount = () => {
            const increment = target / speed;
            if (count < target) {
                count += increment;
                counter.innerText = Math.ceil(count);
                setTimeout(updateCount, 20);
            } else {
                counter.innerText = target;
            }
        };

        updateCount();
    });
}

// Run counter when page loads
window.onscroll = startCounter;

let arr1 = [256, 678, 320];
let arr2 = [345, 569, 600];

// Use map() to add corresponding elements
let result = arr1.map((a, i) => a + arr2[i]);

console.log(result);








 